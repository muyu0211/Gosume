// popup：连接本地桥 → 取简历 → 检测本页表单 → 生成并编辑映射 → 写入。
(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const state = {
    creds: null,      // { port, token }
    payload: null,    // 简历 Payload
    fields: [],       // 本页检测到的表单字段
    plan: [],         // [{ field, value }] 待写入
  };

  const ui = {
    dot: $('statusDot'),
    connectView: $('connectView'),
    mainView: $('mainView'),
    resumeInfo: $('resumeInfo'),
    portInput: $('portInput'),
    tokenInput: $('tokenInput'),
    connectMsg: $('connectMsg'),
    scanMsg: $('scanMsg'),
    fillMsg: $('fillMsg'),
    mapList: $('mapList'),
    scanBtn: $('scanBtn'),
    fillBtn: $('fillBtn'),
    fillArea: $('fillArea'),
  };

  async function getActiveTabId() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab && tab.id;
  }

  function bridgeUrl(path) {
    return `http://127.0.0.1:${state.creds.port}${path}`;
  }

  async function bridgeFetch(path) {
    const res = await fetch(bridgeUrl(path), {
      headers: { Authorization: 'Bearer ' + state.creds.token },
      cache: 'no-store',
    });
    if (!res.ok) {
      if (res.status === 401) throw new Error('鉴权失败，请重新配对');
      throw new Error('连接失败 (' + res.status + ')');
    }
    return res.json();
  }

  function setConnected(on, errText) {
    ui.dot.className = 'dot' + (on ? ' on' : errText ? ' err' : '');
    ui.connectView.hidden = on;
    ui.mainView.hidden = !on;
    if (on) loadResumeAndShow();
    else if (errText) ui.connectMsg.textContent = errText;
  }

  async function loadResumeAndShow() {
    try {
      state.payload = await bridgeFetch('/api/resume');
      const name = state.payload.resume_name || '未命名简历';
      ui.resumeInfo.innerHTML =
        `<strong>简历：${escapeHtml(name)}</strong>` +
        `<small>共 ${Object.keys(state.payload.fields || {}).length} 个可用字段</small>`;
      ui.scanMsg.textContent = '';
    } catch (e) {
      ui.connectMsg.textContent = '取简历失败：' + e.message;
    }
  }

  // ---- 连接 ----
  async function saveCreds(port, token) {
    state.creds = { port: Number(port) || 47621, token: token.trim() };
    await chrome.storage.local.set({ creds: state.creds });
  }

  async function connect(port, token) {
    if (!token) { ui.connectMsg.textContent = '请输入配对 token'; return; }
    await saveCreds(port, token);
    // 校验连接：status 接口无鉴权，探测桥是否在运行
    try {
      const res = await fetch(bridgeUrl('/api/status'), { cache: 'no-store' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      await res.json();
    } catch (e) {
      ui.connectMsg.className = 'msg err';
      ui.connectMsg.textContent = '无法连接 Gosume（' + e.message + '）。请确认应用已启动。';
      return;
    }
    ui.connectMsg.className = 'msg';
    ui.connectMsg.textContent = '已连接。';
    setConnected(true);
  }

  $('connectBtn').addEventListener('click', () => {
    connect(ui.portInput.value, ui.tokenInput.value);
  });

  $('pastePairBtn').addEventListener('click', async () => {
    try {
      const text = await navigator.clipboard.readText();
      const m = text.match(/gosume:\/\/autofill\?port=(\d+)&token=([0-9a-f]+)/i);
      if (!m) { ui.connectMsg.className = 'msg err'; ui.connectMsg.textContent = '剪贴板中没有有效的配对码格式'; return; }
      ui.portInput.value = m[1];
      ui.tokenInput.value = m[2];
      connect(m[1], m[2]);
    } catch (e) {
      ui.connectMsg.className = 'msg err';
      ui.connectMsg.textContent = '无法读取剪贴板，请手动填写';
    }
  });

  // ---- 检测本页表单 ----
  ui.scanBtn.addEventListener('click', async () => {
    ui.scanMsg.textContent = '';
    if (!state.payload) await loadResumeAndShow();
    const tabId = await getActiveTabId();
    if (tabId == null) { ui.scanMsg.className = 'msg err'; ui.scanMsg.textContent = '无法访问当前标签页'; return; }
    const resp = await chrome.tabs.sendMessage(tabId, { type: 'GOSUME_COLLECT_FIELDS' }).catch(() => null);
    if (!resp || !resp.fields) {
      ui.scanMsg.className = 'msg err';
      ui.scanMsg.textContent = '未检测到可填写控件，或此页不是表单页。';
      return;
    }
    state.fields = resp.fields;
    buildMapping();
  });

  function buildMapping() {
    const resumeFields = window.GosumeMap.listResumeFields(state.payload);
    ui.mapList.innerHTML = '';
    state.plan = [];

    state.fields.forEach((field) => {
      const suggested = window.GosumeMap.suggestField(field, state.payload);
      const row = document.createElement('div');
      row.className = 'rowmap' + (suggested ? '' : ' miss');

      const lbl = document.createElement('span');
      lbl.className = 'lbl';
      lbl.textContent = field.label || field.key;

      const right = document.createElement('span');
      right.className = 'src';

      const sel = document.createElement('select');
      const noneOpt = document.createElement('option');
      noneOpt.value = '';
      noneOpt.textContent = '— 不填写 —';
      sel.appendChild(noneOpt);
      resumeFields.forEach((rf, i) => {
        const opt = document.createElement('option');
        opt.value = rf.key;
        opt.textContent = `${rf.label}：${rf.value}`;
        if (rf.key === suggested) opt.selected = true;
        sel.appendChild(opt);
      });

      right.appendChild(sel);
      row.appendChild(lbl);
      row.appendChild(right);
      ui.mapList.appendChild(row);

      // 记住字段对象的引用，供写入时定位
      const rowMeta = { field, sel, suggested };
      sel.dataset.row = state.plan.length;
      state.plan.push({ field, value: suggested ? state.payload.fields[suggested] : '' });
      sel.addEventListener('change', () => {
        const key = sel.value;
        state.plan[rowMeta.sel.dataset.row].value = key ? state.payload.fields[key] || '' : '';
        rowMeta.field.gotValue = !!key;
      });
    });

    ui.fillArea.hidden = state.fields.length === 0;
    ui.scanMsg.className = 'msg';
    ui.scanMsg.textContent = `检测到 ${state.fields.length} 个可填写控件。确认映射后点击“写入表单”。`;
  }

  // ---- 写入 ----
  ui.fillBtn.addEventListener('click', async () => {
    const plan = state.plan.filter((p) => p.value && String(p.value).trim());
    if (!plan.length) { ui.fillMsg.className = 'msg err'; ui.fillMsg.textContent = '没有选择要写入的字段。'; return; }
    const tabId = await getActiveTabId();
    if (tabId == null) { ui.fillMsg.textContent = '无法访问当前标签页'; return; }
    const resp = await chrome.tabs.sendMessage(tabId, { type: 'GOSUME_FILL', plan }).catch((e) => ({ results: [], error: String(e) }));
    const filled = (resp.results || []).filter((r) => r.status === 'filled').length;
    const total = plan.length;
    ui.fillMsg.className = 'msg';
    ui.fillMsg.textContent =
      resp.error ? '写入失败：' + resp.error :
      `已写入 ${filled}/${total} 个字段。已写入的控件会高亮片刻。`;
  });

  $('freshBtn').addEventListener('click', () => {
    if (state.payload) {
      ui.scanBtn.click();
    }
  });

  // ---- 启动 ----
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  (async function init() {
    const stored = await chrome.storage.local.get('creds');
    if (stored.creds) {
      ui.portInput.value = stored.creds.port;
      ui.tokenInput.value = stored.creds.token;
      connect(stored.creds.port, stored.creds.token);
    }
  })();
})();