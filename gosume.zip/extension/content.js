// content script：在页面内收集可填写的表单控件，并按 popup 的填充计划写入。
// 仅在收到消息时动作，不主动改动页面。
(function () {
  'use strict';

  const SKIP_TYPES = new Set(['hidden', 'password', 'file', 'submit', 'button', 'reset', 'image']);

  function isEditable(el) {
    if (!(el instanceof Element)) return false;
    if (el.disabled || el.readOnly) return false;
    if (SKIP_TYPES.has((el.type || '').toLowerCase())) return false;
    const style = getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden') return false;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return false;
    return true;
  }

  function findLabel(el) {
    if (el.id) {
      const forLabel = document.querySelector('label[for="' + window.CSS.escape(el.id) + '"]');
      if (forLabel && forLabel.textContent.trim()) return forLabel.textContent.trim();
    }
    const wrapped = el.closest('label');
    if (wrapped && wrapped.textContent.trim()) {
      return wrapped.textContent.replace(el.value || '', '').trim();
    }
    if (el.getAttribute('aria-label')) return el.getAttribute('aria-label').trim();
    if (el.getAttribute('placeholder')) return el.getAttribute('placeholder').trim();
    if (el.name) return el.name;
    return '';
  }

  function makeKey(el, pos) {
    if (el.id) return '#' + window.CSS.escape(el.id);
    if (el.name) return '[name=' + JSON.stringify(el.name) + ']';
    return 'pos:' + pos;
  }

  // 以与收集时间相同的顺序取当前页面可编辑控件，用于按位置兜底定位。
  function editableControls() {
    const out = [];
    document.querySelectorAll('input, select, textarea').forEach((el) => {
      if (isEditable(el)) out.push(el);
    });
    return out;
  }

  function collect() {
    const result = [];
    const seen = new Set();
    let pos = 0;
    editableControls().forEach((el) => {
      const key = makeKey(el, pos);
      if (seen.has(key)) return;
      seen.add(key);
      result.push({
        key,
        positional: pos,
        tag: el.tagName.toLowerCase(),
        type: (el.type || '').toLowerCase(),
        label: findLabel(el),
        value: el.value || '',
        required: el.required || el.hasAttribute('required'),
      });
      pos++;
    });
    return result;
  }

  function locate(field) {
    if (field.key && !field.key.startsWith('pos:')) {
      try {
        const el = document.querySelector(field.key);
        if (el && isEditable(el)) return el;
      } catch (e) {
        /* ignore selector errors */
      }
    }
    const all = editableControls();
    const idx = typeof field.positional === 'number' ? field.positional : -1;
    return idx >= 0 && idx < all.length ? all[idx] : null;
  }

  function setNativeValue(el, value) {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function fillOne(field, value) {
    const el = locate(field);
    if (!el) return { key: field.key, status: 'skipped' };
    try {
      if (el.tagName === 'SELECT') {
        const ok = fillSelect(el, value);
        return { key: field.key, status: ok ? 'filled' : 'skipped' };
      }
      setNativeValue(el, String(value));
    } catch (e) {
      return { key: field.key, status: 'error' };
    }
    highlight(el);
    return { key: field.key, status: 'filled' };
  }

  function fillSelect(el, value) {
    const options = Array.from(el.options);
    // 优先值相等
    let opt = options.find((o) => o.value === String(value));
    if (!opt) {
      // text 相等（去掉序号前缀）
      opt = options.find((o) => o.text.trim() === String(value));
      if (!opt) {
        const v = String(value).split(/[.、\s]/)[0];
        const prefix = options.find((o) => o.text.replace(/^(\d+[.)、\s])/, '').trim() === String(value).trim());
        if (prefix) opt = prefix;
      }
    }
    if (!opt && options.length && el.required) return false;
    if (opt) {
      el.value = opt.value;
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }
    return false;
  }

  function highlight(el) {
    const old = el.style.outline;
    el.style.outline = '2px solid #4b3fe3';
    el.style.transition = 'outline-color .3s';
    setTimeout(() => {
      el.style.outline = old;
    }, 1500);
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || typeof msg !== 'object') return;
    switch (msg.type) {
      case 'GOSUME_COLLECT_FIELDS':
        sendResponse({ fields: collect() });
        return false; // sync response
      case 'GOSUME_FILL':
        const results = (msg.plan || []).map((row) => fillOne(row.field, row.value));
        sendResponse({ results });
        return false;
      default:
        return false;
    }
  });

  // 让脚本在每次消息时都处于就绪状态（配合非持久化注入）。
  console.debug('[gosume-autofill] content script ready');
})();